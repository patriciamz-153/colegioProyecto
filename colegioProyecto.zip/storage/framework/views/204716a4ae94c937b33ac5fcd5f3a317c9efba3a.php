

<?php $__env->startSection('content'); ?>

    <div class = 'container'>
      <div class= "arrow">
        <h1><?php echo e($data->Name); ?></h1>
        <?php if(property_exists ($data,"Description")): ?><p style="color:red;"><?php echo e($data->Description); ?></p><?php endif; ?>
        <div class="row">
          <div class="col-xs-12 col-sm-12">
            <form method="POST" class="form-horizontal">
              <?php echo e(csrf_field()); ?>

              <?php $i = 0;?>
              <?php $__currentLoopData = $data->Section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="panel panel-default">
                <div class="panel-heading">
                <h4 class="panel-title"><?php echo e($section->Title); ?></h4>
                </div>

                <div class="panel-body" id="idAlert" style="display:none;">
                  <div class="alert alert-danger alert-dismissible" role="alert">
                      <strong>Imcompleto</strong>, faltan completar algunos datos.
                  </div>
                </div>

                <div class="panel-body">
                  <?php if(property_exists ($section,"Description")): ?><p><?php echo e($section->Description); ?></p><?php endif; ?>
                  <?php $__currentLoopData = $section->Preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <div class="form-group">
                    <label class="col-sm-4 control-label"><?php echo e($pregunta->Enunciado); ?><span style="color:red;"><strong> *</strong></span>:</label>
                    <div class="<?php echo e(strtolower($pregunta->Type)); ?> col-sm-8">
                      <?php $__currentLoopData = $pregunta->Options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php $__currentLoopData = $option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <label class="col-sm-2" for="id<?php echo e($key.$i); ?>"><input type="<?php echo e(strtolower($pregunta->Type)); ?>" name="<?php echo e($pregunta->Enunciado); ?><?php if($pregunta->Type=="Checkbox"): ?>[]<?php endif; ?>" id="id<?php echo e($key.$i++); ?>" value="<?php echo e($key); ?>"><?php echo e($key); ?></label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <div class="form-group">
                <div class="col-sm-10 col-sm-offset-6">
                  <input id="idEnviar" type="submit" class="btn btn-default" value="Enviar" />
                </div>
              </div>
            </form>
          </div>
        </div>

      </div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('js/frmUno.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>