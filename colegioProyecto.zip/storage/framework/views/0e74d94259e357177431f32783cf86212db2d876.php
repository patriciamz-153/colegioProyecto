<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sistema de Encuestas | Colegio Maranguita</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <link href="<?php echo e(url('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/welcomeStyle.css')); ?>" rel="stylesheet" type="text/css">

    </head>
    <body>
        <div class="position-ref full-height" style="background-image: url(<?php echo e(asset('imagenes/encuestas2.jpg')); ?>);background-repeat: no-repeat; background-size: cover;background-position: top center;">
          <div class="top-left links" style="margin-bottom: 20px;height: 60px;">
            <a href="<?php echo e(url('/')); ?>">Colegio Maranguita</a>
          </div>
          <div class="top-right links">
            <a href="<?php echo e(url('/home')); ?>">
              <span class="glyphicon glyphicon-user" aria-hidden="true"></span> <?php echo e(Auth::user()->nombres); ?>

            </a>
            <a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
              <span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> Salir
            </a>
            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
          </div>

          <div class = 'container' style=" float:left; background-color: #222; opacity: .9; margin-top: 100px;">
            <div class="title text-left" style="font-family:Montserrat-Regular;">
                <?php echo e($data->Name); ?>

            </div>
            <div class="links" style="font-family:Montserrat-Regular;color:#fff">
                <?php if(property_exists ($data,"Description")): ?><p style="color:red;"><?php echo e($data->Description); ?></p><?php endif; ?>
            </div><br>
            <div class="row links" style="background-position: top center; font-family:Montserrat-Regular;background-color: #222;opacity: .9;">
              <form method="POST" class="form-horizontal">
                <?php echo e(csrf_field()); ?>

                <?php $i = 0;?>
                <?php $__currentLoopData = $data->Section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="panel panel-default">
                  <div class="panel-heading">
                  <h4 class="panel-title"><?php echo e($section->Title); ?></h4>
                  </div>
                  <div class="panel-body" id="idAlert" style="display:none;">
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <strong>Imcompleto</strong>, faltan completar algunos datos.
                    </div>
                  </div>
                  <div class="panel-body">
                    <?php if(property_exists ($section,"Description")): ?><p><?php echo e($section->Description); ?></p><?php endif; ?>
                    <?php $__currentLoopData = $section->Preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="form-group">
                      <label class="col-sm-4 control-label"><?php echo e($pregunta->Enunciado); ?><span style="color:red;"><strong> *</strong></span>:</label>
                      <div class="<?php echo e(strtolower($pregunta->Type)); ?> col-sm-8">
                        <?php $__currentLoopData = $pregunta->Options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <?php $__currentLoopData = $option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <label class="col-sm-2" for="id<?php echo e($key.$i); ?>"><input type="<?php echo e(strtolower($pregunta->Type)); ?>" name="<?php echo e($pregunta->Enunciado); ?><?php if($pregunta->Type=="Checkbox"): ?>[]<?php endif; ?>" id="id<?php echo e($key.$i++); ?>" value="<?php echo e($key); ?>"><?php echo e($key); ?></label>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <div class="form-group">
                  <div class="col-sm-10 col-sm-offset-6">
                    <input id="idEnviar" type="submit" class="btn btn-default" value="Enviar" />
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
    </body>
</html>
