




<?php $__env->startSection("content"); ?>

<div class="row" id="app">
        <div class="panel panel-info">

                <div class="panel-heading text-center">
                     <h3>Contactenos</h3>
                 </div>
<div class="container">
	<?php if(count($errors) > 0): ?>
	<div class="alert alert-danger" role="alert">
		* <?php echo e($errors->first('nombre')); ?> 
		<br>
		* <?php echo e($errors->first('email')); ?>

		<br>
		* <?php echo e($errors->first('text')); ?>

	</div>
	<?php endif; ?>
	<form method="POST">
		<input type="hidden" id="_token" name="_token" value="<?php echo e(csrf_token()); ?>">
	  	<div class="form-group">
	    	<label for="nombre">Nombres Completos: </label>
	    	<input type="text" class="form-control" id="nombre" name="nombre">
	  	</div>
		<div class="form-group">
	    	<label for="email">Email: </label>
	    	<input type="email" class="form-control" id="email" name="email">
	  	</div>
	  	<div class="form-group">
	    	<label for="text">Escribe tu mensaje: </label>
	    	<textarea id="text" name="text" class="form-control" rows="3"></textarea>
	  	</div>
		<input type="button" class="btn btn-default" onclick="confirm('Su mensaje sera enviado, Muchas gracias')" value="Enviar" />
  	
	</form>
</div>
</div>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>