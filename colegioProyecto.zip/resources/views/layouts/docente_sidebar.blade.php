<div class="navbar-default sidebar" role="navigation">
    <div class="navbar-collapse collapse">
    <ul class="nav in">
        <li>
            <a class="sidebar-link" href="{{ route('grupos.index') }}">Grupos</a>
        </li>
    </ul>
    </div>
</div>